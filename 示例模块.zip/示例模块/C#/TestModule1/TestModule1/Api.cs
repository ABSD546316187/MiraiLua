﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using KeraLua;

namespace TestModule1
{
    internal class Api
    {
        static public List<IntPtr> Funs = new List<IntPtr>();
        public enum PrintType { INFO, WARNING, ERROR }

        //print
        delegate void Delegate_Print(string t, PrintType printType, ConsoleColor color);
        static public void API_Print(string t,PrintType printType = PrintType.INFO,ConsoleColor color = ConsoleColor.Gray)
        {
            int ind = 0;
            Delegate_Print f = (Delegate_Print)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Print));
            f(t,printType,color);
        }

        public delegate int Delegate_Lua(IntPtr p);
        delegate void Delegate_Lua_PushFunction(IntPtr p, string table, string name);
        static public void Lua_PushFunction(Delegate_Lua f, string table, string name)
        {
            int ind = 1;

            IntPtr p = Marshal.GetFunctionPointerForDelegate(new Delegate_Lua(f));
            Delegate_Lua_PushFunction f1 = (Delegate_Lua_PushFunction)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_PushFunction));
            f1(p, table, name);
        }

        delegate void Delegate_Lua_PushBoolean(bool n);
        static public void Lua_PushBoolean(bool n)
        {
            int ind = 2;
            Delegate_Lua_PushBoolean f = (Delegate_Lua_PushBoolean)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_PushBoolean));
            f(n);
        }

        delegate void Delegate_Lua_PushCopy(bool n);
        static public void Lua_PushCopy(bool n)
        {
            int ind = 3;
            Delegate_Lua_PushCopy f = (Delegate_Lua_PushCopy)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_PushCopy));
            f(n);
        }

        delegate void Delegate_Lua_PushInteger(long n);
        static public void Lua_PushInteger(long n)
        {
            int ind = 4;
            Delegate_Lua_PushInteger f = (Delegate_Lua_PushInteger)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_PushInteger));
            f(n);
        }

        delegate void Delegate_Lua_PushNil();
        static public void Lua_PushNil()
        {
            int ind = 5;
            Delegate_Lua_PushNil f = (Delegate_Lua_PushNil)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_PushNil));
            f();
        }

        delegate void Delegate_Lua_PushNumber(double n);
        static public void Lua_PushNumber(double n)
        {
            int ind = 6;
            Delegate_Lua_PushNumber f = (Delegate_Lua_PushNumber)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_PushNumber));
            f(n);
        }

        delegate void Delegate_Lua_PushString(string n);
        static public void Lua_PushString(string n)
        {
            int ind = 7;
            Delegate_Lua_PushString f = (Delegate_Lua_PushString)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_PushString));
            f(n);
        }

        delegate void Delegate_Lua_CheckAny(int n);
        static public void Lua_CheckAny(int n)
        {
            int ind = 8;
            Delegate_Lua_CheckAny f = (Delegate_Lua_CheckAny)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_CheckAny));
            f(n);
        }

        delegate long Delegate_Lua_CheckInteger(int n);
        static public long Lua_CheckInteger(int n)
        {
            int ind = 9;
            Delegate_Lua_CheckInteger f = (Delegate_Lua_CheckInteger)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_CheckInteger));
            return f(n);
        }

        delegate double Delegate_Lua_CheckNumber(int n);
        static public double Lua_CheckNumber(int n)
        {
            int ind = 10;
            Delegate_Lua_CheckNumber f = (Delegate_Lua_CheckNumber)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_CheckNumber));
            return f(n);
        }

        delegate bool Delegate_Lua_CheckStack(int n);
        static public bool Lua_CheckStack(int n)
        {
            int ind = 11;
            Delegate_Lua_CheckStack f = (Delegate_Lua_CheckStack)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_CheckStack));
            return f(n);
        }

        delegate string Delegate_Lua_CheckString(int n);
        static public string Lua_CheckString(int n)
        {
            int ind = 12;
            Delegate_Lua_CheckString f = (Delegate_Lua_CheckString)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_CheckString));
            return f(n);
        }

        delegate void Delegate_Lua_CheckType(int n, LuaType t);
        static public void Lua_CheckType(int n,LuaType t)
        {
            int ind = 13;
            Delegate_Lua_CheckType f = (Delegate_Lua_CheckType)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_CheckType));
            f(n,t);
        }

        delegate IntPtr Delegate_Lua_CheckUserData(int n, string name);
        static public IntPtr Lua_CheckUserData(int n, string name)
        {
            int ind = 14;
            Delegate_Lua_CheckUserData f = (Delegate_Lua_CheckUserData)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_CheckUserData));
            return f(n,name);
        }

        delegate LuaType Delegate_Lua_GetField(int n, string k);
        static public LuaType Lua_GetField(int n, string k)
        {
            int ind = 15;
            Delegate_Lua_GetField f = (Delegate_Lua_GetField)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetField));
            return f(n,k);
        }

        delegate LuaType Delegate_Lua_GetGlobal(string n);
        static public LuaType Lua_GetGlobal(string n)
        {
            int ind = 16;
            Delegate_Lua_GetGlobal f = (Delegate_Lua_GetGlobal)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetGlobal));
            return f(n);
        }

        delegate LuaType Delegate_Lua_GetInteger(int n, long i);
        static public LuaType Lua_GetInteger(int n, long i)
        {
            int ind = 17;
            Delegate_Lua_GetInteger f = (Delegate_Lua_GetInteger)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetInteger));
            return f(n,i);
        }

        delegate string Delegate_Lua_GetLocal(int ar, int n);
        static public string Lua_GetLocal(int ar, int n)
        {
            int ind = 18;
            Delegate_Lua_GetLocal f = (Delegate_Lua_GetLocal)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetLocal));
            return f(ar,n);
        }

        delegate LuaType Delegate_Lua_GetMetaField(int n, string f);
        static public LuaType Lua_GetMetaField(int n, string f)
        {
            int ind = 19;
            Delegate_Lua_GetMetaField f2 = (Delegate_Lua_GetMetaField)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetMetaField));
            return f2(n, f);
        }

        delegate bool Delegate_Lua_GetMetaTable(int n);
        static public bool Lua_GetMetaTable(int n)
        {
            int ind = 20;
            Delegate_Lua_GetMetaTable f = (Delegate_Lua_GetMetaTable)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetMetaTable));
            return f(n);
        }

        delegate int Delegate_Lua_GetStack(int n, int ar);
        static public int Lua_GetStack(int n, int ar)
        {
            int ind = 21;
            Delegate_Lua_GetStack f = (Delegate_Lua_GetStack)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetStack));
            return f(n, ar);
        }

        delegate bool Delegate_Lua_GetSubTable(int n, string name);
        static public bool Lua_GetSubTable(int n,string name)
        {
            int ind = 22;
            Delegate_Lua_GetSubTable f = (Delegate_Lua_GetSubTable)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetSubTable));
            return f(n, name);
        }

        delegate LuaType Delegate_Lua_GetTable(int n);
        static public LuaType Lua_GetTable(int n)
        {
            int ind = 23;
            Delegate_Lua_GetTable f = (Delegate_Lua_GetTable)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetTable));
            return f(n);
        }

        delegate int Delegate_Lua_GetTop();
        static public int Lua_GetTop()
        {
            int ind = 24;
            Delegate_Lua_GetTop f = (Delegate_Lua_GetTop)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetTop));
            return f();
        }

        delegate string Delegate_Lua_GetUpValue(int funcindex, int n);
        static public string Lua_GetUpValue(int funcindex,int n)
        {
            int ind = 25;
            Delegate_Lua_GetUpValue f = (Delegate_Lua_GetUpValue)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetUpValue));
            return f(funcindex, n);
        }

        delegate int Delegate_Lua_GetUserValue(int n);
        static public int Lua_GetUserValue(int n)
        {
            int ind = 26;
            Delegate_Lua_GetUserValue f = (Delegate_Lua_GetUserValue)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_GetUserValue));
            return f(n);
        }

        delegate void Delegate_Lua_SetField(int n, string k);
        static public void Lua_SetField(int n, string k)
        {
            int ind = 27;
            Delegate_Lua_SetField f = (Delegate_Lua_SetField)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetField));
            f(n, k);
        }

        delegate void Delegate_Lua_SetGlobal(string n);
        static public void Lua_SetGlobal(string n)
        {
            int ind = 28;
            Delegate_Lua_SetGlobal f = (Delegate_Lua_SetGlobal)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetGlobal));
            f(n);
        }

        delegate void Delegate_Lua_SetInteger(int n, long i);
        static public void Lua_SetInteger(int n,long i)
        {
            int ind = 29;
            Delegate_Lua_SetInteger f = (Delegate_Lua_SetInteger)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetInteger));
            f(n,i);
        }

        delegate string Delegate_Lua_SetLocal(int ar, int n);
        static public string Lua_SetLocal(int ar,int n)
        {
            int ind = 30;
            Delegate_Lua_SetLocal f = (Delegate_Lua_SetLocal)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_SetLocal));
            return f(ar,n);
        }

        delegate void Delegate_Lua_SetMetaTable(int n);
        static public void Lua_SetMetaTable(int n)
        {
            int ind = 31;
            Delegate_Lua_SetMetaTable f = (Delegate_Lua_SetMetaTable)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetMetaTable));
            f(n);
        }

        delegate void Delegate_Lua_SetTable(int n);
        static public void Lua_SetTable(int n)
        {
            int ind = 32;
            Delegate_Lua_SetTable f = (Delegate_Lua_SetTable)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetTable));
            f(n);
        }

        delegate void Delegate_Lua_SetTop(int n);
        static public void Lua_SetTop(int n)
        {
            int ind = 33;
            Delegate_Lua_SetTop f = (Delegate_Lua_SetTop)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetTop));
            f(n);
        }

        delegate string Delegate_Lua_SetUpValue(int funcindex, int n);
        static public string Lua_SetUpValue(int funcindex, int n)
        {
            int ind = 34;
            Delegate_Lua_SetUpValue f = (Delegate_Lua_SetUpValue)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetUpValue));
            return f(funcindex, n);
        }

        delegate void Delegate_Lua_SetUserValue(int n);
        static public void Lua_SetUserValue(int n)
        {
            int ind = 35;
            Delegate_Lua_SetUserValue f = (Delegate_Lua_SetUserValue)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetUserValue));
            f(n);
        }

        delegate void Delegate_Lua_SetIndexedUserValue(int index, int n);
        static public void Lua_SetIndexedUserValue(int index, int n)
        {
            int ind = 36;
            Delegate_Lua_SetIndexedUserValue f = (Delegate_Lua_SetIndexedUserValue)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_SetIndexedUserValue));
            f(index, n);
        }

        delegate void Delegate_Lua_Pop(int n);
        static public void Lua_Pop(int n)
        {
            int ind = 37;
            Delegate_Lua_Pop f = (Delegate_Lua_Pop)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_Pop));
            f(n);
        }

        delegate void Delegate_Lua_Call(int args, int results);
        static public void Lua_Call(int args, int results)
        {
            int ind = 38;
            Delegate_Lua_Call f = (Delegate_Lua_Call)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_Call));
            f(args, results);
        }

        delegate LuaStatus Delegate_Lua_PCall(int args, int results, int errindex);
        static public LuaStatus Lua_PCall(int args, int results, int errindex)
        {
            int ind = 39;
            Delegate_Lua_PCall f = (Delegate_Lua_PCall)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_PCall));
            return f(args, results, errindex);
        }

        delegate bool Delegate_Lua_Next(int index);
        static public bool Lua_Next(int index)
        {
            int ind = 40;
            Delegate_Lua_Next f = (Delegate_Lua_Next)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_Next));
            return f(index);
        }

        delegate bool Delegate_Lua_ToBoolean(int index);
        static public bool Lua_ToBoolean(int index)
        {
            int ind = 41;
            Delegate_Lua_ToBoolean f = (Delegate_Lua_ToBoolean)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_ToBoolean));
            return f(index);
        }

        delegate long Delegate_Lua_ToInteger(int index);
        static public long Lua_ToInteger(int index)
        {
            int ind = 42;
            Delegate_Lua_ToInteger f = (Delegate_Lua_ToInteger)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_ToInteger));
            return f(index);    
        }

        delegate double Delegate_Lua_ToNumber(int index);
        static public double Lua_ToNumber(int index)
        {
            int ind = 43;
            Delegate_Lua_ToNumber f = (Delegate_Lua_ToNumber)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_ToNumber));
            return f(index);
        }

        delegate IntPtr Delegate_Lua_ToPointer(int index);
        static public IntPtr Lua_ToPointer(int index)
        {
            int ind = 44;
            Delegate_Lua_ToPointer f = (Delegate_Lua_ToPointer)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_ToPointer));
            return f(index);
        }

        delegate string Delegate_Lua_ToString(int index);
        static public string Lua_ToString(int index)
        {
            int ind = 45;
            Delegate_Lua_ToString f = (Delegate_Lua_ToString)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_ToString));
            return f(index);
        }

        delegate IntPtr Delegate_Lua_ToUserData(int index);
        static public IntPtr Lua_ToUserData(int index)
        {
            int ind = 46;
            Delegate_Lua_ToUserData f = (Delegate_Lua_ToUserData)Marshal.GetDelegateForFunctionPointer(Funs[ind],typeof(Delegate_Lua_ToUserData));
            return f(index);
        }

        // 47 Delegates
        delegate void Delegate_Lua_NewTable();
        static public void Lua_NewTable()
        {
            int ind = 47;
            Delegate_Lua_NewTable f = (Delegate_Lua_NewTable)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_NewTable));
            f();
        }

        delegate LuaType Delegate_Lua_Type(int index);
        static public LuaType Lua_Type(int index)
        {
            int ind = 48;
            Delegate_Lua_Type f = (Delegate_Lua_Type)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_Type));
            return f(index);
        }

        delegate void Delegate_Lua_PushByteArray(int p, int l);
        static public void Lua_PushByteArray(byte[] B)
        {
            int ind = 49;
            Delegate_Lua_PushByteArray f = (Delegate_Lua_PushByteArray)Marshal.GetDelegateForFunctionPointer(Funs[ind], typeof(Delegate_Lua_PushByteArray));

            IntPtr dp = Marshal.AllocHGlobal(B.Length);
            Marshal.Copy(B, 0, dp, B.Length);

            f((int)dp,B.Length);
        }
    }
}
