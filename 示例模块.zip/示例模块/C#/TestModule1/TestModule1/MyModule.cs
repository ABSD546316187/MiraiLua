﻿using KeraLua;
using System;
using System.Runtime.InteropServices;

namespace TestModule1
{
    public class MyModule
    {
        static byte[] B = new byte[0];
        delegate void Delegate_InitCallback(IntPtr p, int l);
        [DllExport(CallingConvention = CallingConvention.StdCall)]
        static public void Init(IntPtr p, IntPtr datap, int datal)//上面的都不用管，除非你想用别的语言写模块
        {
            try
            {
                //注册必要信息
                var data = new Data(new byte[0]);//请在这里修改你的模块信息

                data.WriteString("C#示例模块");//名称
                data.WriteString("1.0");//版本
                data.WriteString("ABSD");//作者

                B = data.GetData();

                //获取主程序的函数指针
                var b = new byte[datal];
                Marshal.Copy(datap, b, 0, datal);//相当于指针到字节集
                
                data = new Data(b);
                int n = data.ReadInt();
                for (int i = 0; i < n; i++)
                {
                    Api.Funs.Add((IntPtr)data.ReadInt());
                }

                //封装数据包 调用回调函数完成模块的注册
                IntPtr dp = Marshal.AllocHGlobal(B.Length);
                Marshal.Copy(B, 0, dp, B.Length);

                var callback = (Delegate_InitCallback)Marshal.GetDelegateForFunctionPointer(p, typeof(Delegate_InitCallback));
                callback(dp, B.Length);
                Marshal.FreeHGlobal(dp);

                //以上内容你不需要管，是固定操作

                //测试
                Api.API_Print("Hello, world!");//使用print api在控制台输出，当然也可以直接用console.writeline
                Api.API_Print("Hello, world!", Api.PrintType.INFO, ConsoleColor.Red);
                Api.API_Print("Hello, world!", Api.PrintType.WARNING, ConsoleColor.Blue);
                Api.API_Print("Hello, world!", Api.PrintType.ERROR, ConsoleColor.Yellow);

                Api.Lua_PushFunction(Test,"_G","Test234");//在全局表压入一个函数
                Api.Lua_Pop(Api.Lua_GetTop());//pushfunction不会自动清空栈，这里要手动清空防止栈溢出
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message + "\n" + e.StackTrace);
            }
        }

        static int Test(IntPtr p)//压入的函数必须有1个intptr的参数和int的返回值
        {//参数p为lua虚拟机指针,但是你无法在模块里面直接用keralua操作主程序的lua
            var b = new byte[4] {1,1,4,5};
            Api.Lua_PushByteArray(b);
            return 1;//这里返回的是参数个数(lua的function可以返回多个值)
        }
    }
}
